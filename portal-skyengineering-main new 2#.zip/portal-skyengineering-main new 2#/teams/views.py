"""
Author: [Your Name]
Description: Teams page - displays all engineering teams with search,
             email, schedule meeting, skills and dependency views.
"""

from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from core.models import TblTeam, TblDepartment, TblUser, TblDependencies
from core.utils import login_required
from accounts.views import is_admin


@login_required
def teams_list(request):
    """Main teams listing page with search support."""
    query = request.GET.get('q', '').strip()

    teams = TblTeam.objects.select_related('department', 'team_leader').all()

    if query:
        teams = teams.filter(name__icontains=query) | \
                teams.filter(department__name__icontains=query) | \
                teams.filter(description__icontains=query)

    # Build enriched team data
    team_data = []
    for team in teams:
        leader = team.team_leader
        leader_name = f"{leader.fname} {leader.sname or ''}".strip() if leader else "No Manager"
        leader_email = leader.email if leader else ""

        dept_name = team.department.name if team.department else "N/A"

        # Get dependencies
        deps = TblDependencies.objects.filter(team=team)
        upstream_deps = [d for d in deps if d.upstream]
        downstream_deps = [d for d in deps if d.downstream]

        # Skills as list
        skills = []
        if team.skills_and_tech:
            skills = [s.strip() for s in team.skills_and_tech.split(',') if s.strip()]

        team_data.append({
            'id': team.id,
            'name': team.name,
            'department': dept_name,
            'manager': leader_name,
            'manager_email': leader_email,
            'description': team.description or '',
            'skills': skills,
            'skills_raw': team.skills_and_tech or '',
            'slack': team.slack or '',
            'wiki': team.wiki or '',
            'active_projects': team.active_projects or 0,
            'upstream_deps': [{'type': d.type, 'team': d.dependency_team_name} for d in upstream_deps],
            'downstream_deps': [{'type': d.type, 'team': d.dependency_team_name} for d in downstream_deps],
        })

    context = {
        'team_data': team_data,
        'query': query,
        'total_teams': len(team_data),
        'is_admin_user': is_admin(request),
    }
    return render(request, 'teams/index.html', context)


@login_required
def team_detail(request, team_id):
    """Detail view for a single team."""
    team = get_object_or_404(TblTeam, id=team_id)

    leader = team.team_leader
    leader_name = f"{leader.fname} {leader.sname or ''}".strip() if leader else "No Manager"
    leader_email = leader.email if leader else ""

    dept_name = team.department.name if team.department else "N/A"

    # Members in this team
    members = TblUser.objects.filter(team=team)

    # Dependencies
    deps = TblDependencies.objects.filter(team=team)
    upstream_deps = [d for d in deps if d.upstream]
    downstream_deps = [d for d in deps if d.downstream]

    # Skills
    skills = []
    if team.skills_and_tech:
        skills = [s.strip() for s in team.skills_and_tech.split(',') if s.strip()]

    context = {
        'team': team,
        'leader_name': leader_name,
        'leader_email': leader_email,
        'dept_name': dept_name,
        'members': members,
        'upstream_deps': upstream_deps,
        'downstream_deps': downstream_deps,
        'skills': skills,
        'is_admin_user': is_admin(request),
    }
    return render(request, 'teams/detail.html', context)
